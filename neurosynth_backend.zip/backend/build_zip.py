"""Explicit allowlist: never package secrets, environments, old notebooks or models."""
from pathlib import Path
import zipfile
ROOT=Path(__file__).resolve().parent
FILES=['app.py','db.py','source_data.py','prepare_data.py','import_data.py','schema.sql',
       'local_db.py','serve.py','verify.py','build_zip.py','requirements.txt','requirements-data.txt',
       'requirements-lock.txt','.env.example','.gitignore','README.md','DEPLOYMENT.md',
       'render.yaml','Procfile','start.sh','.python-version','templates/index.html','tests/test_integration.py']
FOLDERS=['data','reports']

def build():
    destination=ROOT.parent/'neurosynth_backend.zip'
    paths=[ROOT/f for f in FILES]
    for folder in FOLDERS:
        paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file()
                     and not any(part.startswith('._') for part in p.relative_to(ROOT).parts)
                     and p.suffix in {'.json','.txt','.gz','.md'})
    with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(paths):
            if not p.is_file():raise FileNotFoundError(p)
            z.write(p,Path('backend')/p.relative_to(ROOT))
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None
        assert not any('/.env' in n and not n.endswith('.env.example') for n in z.namelist())
        assert not any(any(x in n.split('/') for x in ('.venv','__pycache__','.pytest_cache')) for n in z.namelist())
    print(f'{destination.name}: {destination.stat().st_size:,} bytes; {len(paths)} files; integrity OK')
if __name__=='__main__':build()
