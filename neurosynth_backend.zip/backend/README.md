# 心理資訊學作業：Neurosynth 研究查詢後端

本專案使用 **Flask + 真正的 PostgreSQL SQL 查詢**。原始 notebook、decoding_results 與舊模型均保留，沒有重新訓練。繳交期限：2026/11/5（四）12:00，Asia/Taipei。

**目前狀態：本機資料庫與四個 API 已驗證；尚未取得公開網址，公開部署與公開 API 測試未完成。localhost 不能當繳交網址。**

## 老師參考專案與暫定定義

2026/10/30 查詢 https://github.com/spiketren/ns-nanosvg 與 GitHub repository API 均回傳 HTTP 404。因此無法閱讀老師 README／相關程式，也無法確認老師期望的輸出格式與 dissociate 定義。使用者亦確認目前沒有其他定義。以下為可調整的**實作假設，不是老師已確認的要求**：

- 詞彙：英文小寫、去除首尾空白、合併連續空白後，精確比對原始詞典，包含多字詞；不做模糊搜尋或模型推論。
- 詞彙條件：原始 `terms_abstract_tfidf__<term>` 分數 **嚴格大於** threshold。預設 `0`，可用 `?threshold=0.01` 改變；兩邊比較用同一門檻。允許有限數字 0–1,000,000。
- 座標：原始 `mni152_2mm` 空間的 mm 座標，以歐氏距離 **小於等於** radius 為符合。預設 `6` mm，`?radius=10` 可調整；比較兩邊用同一半徑。允許 `0 < radius <= 100`，各座標值限 -200–200。
- `dissociate(A,B)` 暫定是**論文集合 A − B**：符合 A，而且完全不符合 B 的論文。它有方向性，反向結果不同；相同輸入得到空集合。不是 TF-IDF 相減、對稱差集、統計顯著性或認知雙重分離的證明。
- 此比較在 `app.py` 的 `dissociate_sql()` 集中實作；之後有老師正式定義時，可更換該函式並同步更新測試、回應說明與首頁。
- 四個固定路徑及 GET 方法保留；JSON 為本次設計，尚無法保證與不可存取的參考專案相同。

## 資料實際格式與研究單位

`neurosynth_dataset.gz` 經 magic bytes 確認是 gzip，內容是 pickle protocol 4 的 NiMARE Dataset，不是 CSV。解壓後 415,687,565 bytes。來源 SHA-256：`8323954e512c5385638195f679fa348963ab5025fbf71319012b8f2b89631852`。

|原始資料／匯入內容|數量|
|---|---:|
|論文 `study_id`|14,371|
|實驗／對比 `id`|14,371|
|原始座標列|507,891|
|原始 TF-IDF 詞彙|3,228|
|正數詞彙分數列（稀疏儲存）|1,049,299|

`id` 例如 `10022492-1` 是實驗／對比，`study_id` 例如 `10022492` 是論文，`contrast_id` 是 `1`。這份資料每篇剛好只有一個對比；設計仍保留三欄並用外鍵確認對應。**API 的 total 與結果均依 study_id 去重**，不是座標數或實驗數。詞彙有任一實驗符合即可，座標有任一原始 focus 符合即可；A − B 在論文層級排除，避免其他實驗符合 B 的同篇論文漏網。

metadata 包含原始 title、authors、journal、year；不憑空補論文資訊。零分詞彙不儲存，threshold 最小 0，故與原始矩陣的 `> threshold` 完全等價。原始座標列保留，包括重複座標；查詢時去重論文。未使用 coordinate_clusters、knn_terms、mlp_terms 等預測結果。

## 本機啟動（目前這台 Mac）

在 VS Code 開啟終端機後：

```sh
cd backend
source .venv/bin/activate
python local_db.py start
sh start.sh
```

看到 Gunicorn listening 訊息後開啟 http://127.0.0.1:5050 。目前已建立 `.venv`、`.env`、資料匯入及本機 PostgreSQL。`.env` 含隨機產生的本機密碼，只在本機，未放入 ZIP。停止網站用 Ctrl+C，停止資料庫用 `python local_db.py stop`。

`local_db.py` 專供這台 Mac／Homebrew：使用 `127.0.0.1:55432`、SCRAM 密碼驗證，資料庫放在 `~/Library/Application Support/neurosynth-homework/pgdata`（避免外接硬碟檔案權限相容問題）。此目錄不進 ZIP。Homebrew 預設 cluster 沒有啟動，也沒有修改其他資料庫。

## 從 ZIP／全新環境啟動

建議 Python 3.14、PostgreSQL 17。runtime 只需要 `requirements.txt`；抽取 pickle 與驗證另裝 `requirements-data.txt`。ZIP 已附上完整原始資料抽取的 `data/`，不必安裝 NiMARE 或重跑模型。

```sh
cd backend
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

建立一個專用 PostgreSQL 資料庫及使用者，複製 `.env.example` 為 `.env`，將 `DATABASE_URL` 換成真正連線字串（雲端外部連線請依平台要求使用 TLS）。密碼有保留字元時必須 URL 編碼。勿將密碼寫入 .py 或 Git。

Mac 若已安裝 Homebrew，可用 `brew install postgresql@17`，然後 `python local_db.py start` 自動建立本機專用資料庫與 `.env`。若已有 `.env`，工具會保留並要求手動確認設定，避免覆寫雲端連線。

```sh
python import_data.py --prepared data
sh start.sh
```

匯入器會驗證每個 CSV.gz SHA-256、format、space、列數、主外鍵，透過 PostgreSQL COPY 寫入，並建立索引。整次匯入是一個 transaction，失敗會 rollback。相同 manifest 與列數會跳過匯入；`--force` 可原子重建**DATABASE_URL 指向的專用作業資料表**，執行前應確認連線目標。`start.sh` 會透過 `serve.py` 同時啟動 Gunicorn 與匯入子程序，以符合 Render 約 5 分鐘的初始連接埠偵測期限；資料完成同一 transaction 提交前，`/health` 不會成功。匯入失敗會停止 HTTP 服務，結束時會清理子程序。沒有在 HTTP request 中匯入資料，也沒有開放公開匯入端點。

## 從原始檔重新準備可攜資料（選用）

把原始 `neurosynth_dataset.gz` 放在 `backend/` 的上一層：

```sh
python -m pip install -r requirements-data.txt
python prepare_data.py --source ../neurosynth_dataset.gz --output data
python import_data.py --prepared data --force
```

`source_data.py` 以明確允許清單讀取這份歷史 pickle；NiMARE 的影像 masker 等不必要物件只以佔位類別接收，原始 pandas／numpy 表格保留。這避免版本相容性與龐大影像套件依賴。只處理可信來源的這份 pickle；不提供使用者上傳 pickle 的 API。若遇到新格式，會明確報錯，不靜默略過。

## 四個 API 範例

以下都是 GET。公開部署後把基底網址換成真正的 `https://...onrender.com`。

|用途|路徑範例|簡單中文說明|
|---|---|---|
|詞彙研究|`/terms/memory/studies`|找出原始摘要詞彙分數中，有 memory 的論文。|
|座標研究|`/locations/-22_0_-20/studies`|找出至少一個原始腦部座標落在指定位置 6 mm 內的論文。|
|詞彙比較|`/dissociate/terms/memory/fear`|暫定：有 memory、但沒有 fear 的論文。|
|座標比較|`/dissociate/locations/-22_0_-20/22_0_-20`|暫定：左側位置附近有座標，但右側位置附近沒有座標的論文。|

測試完整指令：

```sh
curl 'http://127.0.0.1:5050/terms/memory/studies?threshold=0.01&page=1&per_page=20'
curl 'http://127.0.0.1:5050/locations/-22_0_-20/studies?radius=10'
curl 'http://127.0.0.1:5050/dissociate/terms/memory/fear'
curl 'http://127.0.0.1:5050/dissociate/locations/-22_0_-20/22_0_-20'
```

多字詞使用 URL 編碼，例如 `/terms/working%20memory/studies`（前提是資料詞典內存在）。所有 API 可用 `page`（預設 1，最大 1,000,000）與 `per_page`（預設 20，最大 100）。依 `study_id COLLATE "C"` **字串**遞增排序，同樣條件與資料下穩定。超過最後一頁回傳空陣列但保留 total。

JSON 包含 `query`（解析後參數、比較方向與暫定標記）、`unit`、`order`、`pagination` 和 `studies`。每篇研究含 study_id、title、authors、journal、year。total 是全部符合論文數，不是這頁列數。計數與分頁在同一 SQL statement/snapshot 完成。

- 400：座標格式、範圍、NaN／Infinity、門檻、半徑、分頁不合法；不支援或重複的 query 參數。
- 404：詞典沒有該詞彙，或路徑不存在。已存在詞彙但高門檻造成沒有研究時為 200 空陣列。
- 503：資料庫無法查詢或 health 尚未匯入完成。
- 500：未預期的程式／設定錯誤。不在 HTTP 回應洩露密碼或 SQL。

## 驗證方法與紀錄

```sh
python -m pip install -r requirements-data.txt
python -m pytest tests -q
# 也可以直接執行：
python verify.py --source ../neurosynth_dataset.gz --report reports/verification.json
```

測試不使用假資料，也不只看 HTTP 200。從**原始 pickle** 直接計算 TF-IDF 條件與座標距離，再與使用 SQL 的 API 做比對：讀取每一頁，比較全部已排序的 study_id，確保無重複、無遺漏、無額外研究，並逐篇核對 title/authors/journal/year。

包含四條路徑、正反向 A − B、相同輸入、不同半徑／詞彙門檻、精確球邊界、大小寫及空白、多字詞、空結果、未知詞、無效座標、錯誤／重複參數、超出頁數與 health。本機通過 39 項檢查（pytest 1 個整合測試包）。預設條件的完整結果：memory 2,744 篇；座標 -22_0_-20 有 547 篇；memory − fear 有 2,702 篇；左側座標 − 右側座標有 344 篇；兩種相同輸入比較皆 0 篇。實際結果見 `reports/verification.json`、`reports/pytest.txt` 與 `reports/local_checks.json`。公開部署尚未測試；不把本機結果當作公開測試結果。

部署後執行相同完整內容驗證：

```sh
python verify.py --source ../neurosynth_dataset.gz --base-url https://真正網址.onrender.com --report reports/public_verification.json
```

只在該指令成功且四條公開 API 內容一致後，才能把公開網址當完成品。首次喚醒可能需約一分鐘。

## 資料庫與檔案結構

`studies`（論文）、`experiments`（對比）、`terms`（詞典）、`term_scores`（原始非零分數）、`coordinates`（原始 focus）、`dataset_info`（來源校驗）。外鍵維持論文／實驗關係；索引支援 term_id/score、座標 bounding box、experiment/study 查詢。座標先用立方體索引縮小範圍，再以球形距離精確篩選。所有使用者輸入透過 psycopg SQL 參數，不拼接輸入。

- `app.py`、`templates/index.html`：四個 API、驗證、分頁與簡易首頁。
- `prepare_data.py`、`source_data.py`：相容性讀取及原始資料抽取。
- `import_data.py`、`schema.sql`：可重複匯入、transaction、索引。
- `db.py`、`.env.example`：環境變數連線。
- `verify.py`、`tests/`、`reports/`：原始資料交叉驗證與結果。
- `render.yaml`、`start.sh`、`serve.py`、`Procfile`：免費 Render 部署設定。
- `DEPLOYMENT.md`：官方免費限制、登入／公開上傳前的待辦。
- `build_zip.py`：明確允許清單打包，不打包秘密或舊模型。

`requirements-lock.txt` 記錄本機完整測試環境，主部署安裝 `requirements.txt`。ZIP 包含完整 data/ 可攜資料，不包含原始 416 MB 解壓 pickle、notebook、模型、`.env`、虛擬環境、快取或 PostgreSQL cluster。原始檔保留在工作區。
