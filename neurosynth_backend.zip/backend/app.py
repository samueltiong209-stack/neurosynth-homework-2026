"""Flask API backed exclusively by parameterized PostgreSQL queries."""
import math
import os
import re
from flask import Flask, jsonify, request, render_template
import psycopg
from werkzeug.exceptions import HTTPException
from db import connect

# Provisional policy, NOT a confirmed instructor definition. Replace this helper
# if the instructor later specifies symmetric difference or statistical dissociation.
def dissociate_sql(left, right):
    return f'SELECT study_id FROM ({left}) a EXCEPT SELECT study_id FROM ({right}) b'

class Invalid(ValueError): pass
class UnknownTerm(LookupError): pass

COORD = re.compile(r'^([+-]?(?:\d+(?:\.\d*)?|\.\d+))_([+-]?(?:\d+(?:\.\d*)?|\.\d+))_([+-]?(?:\d+(?:\.\d*)?|\.\d+))$')

def create_app(test_config=None):
    app=Flask(__name__)
    app.config.update(DEFAULT_RADIUS_MM=float(os.environ.get('DEFAULT_RADIUS_MM','6')),
                      DEFAULT_THRESHOLD=float(os.environ.get('DEFAULT_THRESHOLD','0')),
                      JSON_SORT_KEYS=False)
    if test_config:app.config.update(test_config)
    for name,low,high in [('DEFAULT_RADIUS_MM',0,100),('DEFAULT_THRESHOLD',0,1e6)]:
        v=app.config[name]
        if not math.isfinite(v) or v<low or v>high or (name=='DEFAULT_RADIUS_MM' and v==0):
            raise ValueError(f'Invalid configuration: {name}')

    def number(name, default, low, high, positive=False):
        try:v=float(request.args.get(name,default))
        except (TypeError,ValueError):raise Invalid(f'{name} 必須是有限數字')
        if not math.isfinite(v) or v<low or v>high or (positive and v==0):
            raise Invalid(f'{name} 範圍為 {low} 到 {high}' + ('，且須大於 0' if positive else ''))
        return v

    def options(kind):
        allowed={'page','per_page'}|({'threshold'} if kind=='terms' else {'radius'})
        unknown=set(request.args)-allowed
        if unknown:raise Invalid('不支援的參數：'+', '.join(sorted(unknown)))
        if any(len(request.args.getlist(k))>1 for k in request.args):raise Invalid('參數不可重複')
        def integer(name,default,maximum):
            raw=request.args.get(name,str(default))
            if not re.fullmatch(r'[0-9]{1,8}',raw):raise Invalid(f'{name} 必須是正整數')
            v=int(raw)
            if not 1<=v<=maximum:raise Invalid(f'{name} 必須介於 1 與 {maximum}')
            return v
        page=integer('page',1,1000000); size=integer('per_page',20,100)
        value=number('threshold',app.config['DEFAULT_THRESHOLD'],0,1e6) if kind=='terms' else number('radius',app.config['DEFAULT_RADIUS_MM'],0,100,True)
        return page,size,value

    def term_query(conn,raw,threshold):
        term=' '.join(raw.strip().lower().split())
        if not term or len(term)>200:raise Invalid('詞彙不可空白，且不可超過 200 字元')
        row=conn.execute('SELECT term_id FROM terms WHERE name=%s',(term,)).fetchone()
        if not row:raise UnknownTerm(f'資料字典中沒有詞彙：{term}')
        sql='SELECT DISTINCT e.study_id FROM term_scores t JOIN experiments e ON e.id=t.experiment_id WHERE t.term_id=%s AND t.score>%s'
        return sql,[row['term_id'],threshold],{'term':term,'threshold':threshold,'operator':'score > threshold'}

    def location_query(raw,radius):
        match=COORD.fullmatch(raw)
        if not match:raise Invalid('座標格式須為 x_y_z，例如 -22_0_-20；單位 mm')
        xyz=tuple(float(v) for v in match.groups())
        if any(not math.isfinite(v) or abs(v)>200 for v in xyz):raise Invalid('每個座標須為 -200 到 200 的有限數值（mm）')
        x,y,z=xyz
        sql='''SELECT DISTINCT e.study_id FROM coordinates c JOIN experiments e ON e.id=c.experiment_id
          WHERE c.x BETWEEN %s AND %s AND c.y BETWEEN %s AND %s AND c.z BETWEEN %s AND %s
          AND (c.x-%s)*(c.x-%s)+(c.y-%s)*(c.y-%s)+(c.z-%s)*(c.z-%s)<=%s'''
        params=[x-radius,x+radius,y-radius,y+radius,z-radius,z+radius,x,x,y,y,z,z,radius*radius]
        return sql,params,{'coordinates_mm':list(xyz),'radius_mm':radius,'space':'mni152_2mm','boundary':'distance <= radius'}

    def result(conn,sql,params,page,size,query):
        # One statement/snapshot for count + page, including pages beyond the end.
        rows=conn.execute(f'''WITH matched AS MATERIALIZED ({sql}),
          total AS (SELECT count(*) AS n FROM matched),
          paged AS (SELECT s.* FROM studies s JOIN matched m USING(study_id)
             ORDER BY s.study_id COLLATE "C" LIMIT %s OFFSET %s)
          SELECT total.n AS total, paged.* FROM total LEFT JOIN paged ON true
          ORDER BY paged.study_id COLLATE "C"''',params+[size,(page-1)*size]).fetchall()
        n=rows[0]['total']; items=[]
        for row in rows:
            if row['study_id'] is not None:
                items.append({k:v for k,v in row.items() if k!='total'})
        return jsonify(query=query,unit='publication / study_id',order='study_id ascending (C collation, lexical)',
                       pagination={'page':page,'per_page':size,'total':n,'total_pages':(n+size-1)//size},studies=items)

    def handle(kind,first,second=None):
        page,size,value=options(kind)
        with connect() as conn:
            def build(raw):return term_query(conn,raw,value) if kind=='terms' else location_query(raw,value)
            left,lp,lq=build(first)
            if second is None:return result(conn,left,lp,page,size,lq)
            right,rp,rq=build(second)
            return result(conn,dissociate_sql(left,right),lp+rp,page,size,
                {'operation':'A_MINUS_B','status':'provisional implementation assumption; instructor definition unavailable',
                 'meaning':'studies matching the first input and not matching the second input','A':lq,'B':rq})

    @app.get('/')
    def index():return render_template('index.html',radius=app.config['DEFAULT_RADIUS_MM'],threshold=app.config['DEFAULT_THRESHOLD'])

    @app.get('/health')
    def health():
        with connect() as conn:
            row=conn.execute('SELECT manifest FROM dataset_info').fetchone()
        if not row:return jsonify(error={'code':'data_not_loaded','message':'尚未匯入資料'}),503
        return jsonify(status='ok',source_sha256=row['manifest']['source_sha256'],counts=row['manifest']['counts'])

    @app.get('/terms/<term>/studies')
    def terms(term):return handle('terms',term)
    @app.get('/locations/<x_y_z>/studies')
    def locations(x_y_z):return handle('locations',x_y_z)
    @app.get('/dissociate/terms/<term1>/<term2>')
    def dissociate_terms(term1,term2):return handle('terms',term1,term2)
    @app.get('/dissociate/locations/<x1_y1_z1>/<x2_y2_z2>')
    def dissociate_locations(x1_y1_z1,x2_y2_z2):return handle('locations',x1_y1_z1,x2_y2_z2)

    @app.errorhandler(Invalid)
    def invalid(e):return jsonify(error={'code':'invalid_parameter','message':str(e)}),400
    @app.errorhandler(UnknownTerm)
    def unknown(e):return jsonify(error={'code':'unknown_term','message':str(e)}),404
    @app.errorhandler(psycopg.Error)
    def database_error(e):
        # Do not log exception text: it may contain database host/credentials.
        app.logger.error('Database error class: %s',type(e).__name__)
        return jsonify(error={'code':'database_unavailable','message':'資料庫暫時無法查詢，請稍後再試或檢查匯入狀態'}),503
    @app.errorhandler(HTTPException)
    def http_error(e):return jsonify(error={'code':e.name,'message':e.description}),e.code
    @app.errorhandler(Exception)
    def unexpected(e):
        app.logger.error('Application error class: %s',type(e).__name__)
        return jsonify(error={'code':'internal_error','message':'伺服器設定或處理錯誤，請查閱後端紀錄'}),500
    return app

app=create_app()
if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.environ.get('PORT','5050')),debug=False)
