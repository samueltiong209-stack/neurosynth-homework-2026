"""Transactional, checksum-verified, idempotent PostgreSQL COPY import."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
from psycopg.types.json import Jsonb
from db import connect

TABLES = {
    'studies':'study_id,title,authors,journal,year',
    'experiments':'id,study_id,contrast_id', 'terms':'term_id,name',
    'coordinates':'experiment_id,x,y,z', 'term_scores':'experiment_id,term_id,score',
}

def import_data(directory, force=False):
    directory=Path(directory)
    manifest=json.loads((directory/'manifest.json').read_text())
    if manifest['format_version']!=1 or manifest['space']!='mni152_2mm': raise ValueError('Unsupported dataset format/space')
    for table in TABLES:
        name=table+'.csv.gz'; h=hashlib.sha256()
        with (directory/name).open('rb') as f:
            for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
        if h.hexdigest()!=manifest['files'][name]:raise ValueError(f'Checksum mismatch: {name}')
    with connect() as conn:
        conn.execute('SET statement_timeout = 0')
        conn.execute("SELECT pg_advisory_xact_lock(71051105)")
        conn.execute(Path(__file__).with_name('schema.sql').read_text())
        old=conn.execute('SELECT manifest FROM dataset_info').fetchone()
        if old and old['manifest']==manifest and not force:
            for table in TABLES:
                if conn.execute(f'SELECT count(*) AS n FROM {table}').fetchone()['n']!=manifest['counts'][table]:
                    raise ValueError('Database counts changed; use --force to restore')
            print('Dataset already imported; checksums/counts match.'); return
        conn.execute('TRUNCATE term_scores, coordinates, experiments, terms, studies, dataset_info')
        for table,columns in TABLES.items():
            with conn.cursor() as cur:
                with cur.copy(f'COPY {table} ({columns}) FROM STDIN WITH (FORMAT csv, HEADER true)') as copy:
                    with gzip.open(directory/(table+'.csv.gz'),'rb') as f:
                        for block in iter(lambda:f.read(1024*1024),b''):copy.write(block)
            n=conn.execute(f'SELECT count(*) AS n FROM {table}').fetchone()['n']
            if n!=manifest['counts'][table]:raise ValueError(f'Count mismatch: {table}')
            print(f'{table}: {n}',flush=True)
        conn.execute('INSERT INTO dataset_info(manifest) VALUES (%s)',(Jsonb(manifest),))
        for table in TABLES:conn.execute(f'ANALYZE {table}')
    print('Import committed.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepared',default=str(Path(__file__).with_name('data')));p.add_argument('--force',action='store_true')
    a=p.parse_args(); import_data(a.prepared,a.force)
