"""Bind HTTP promptly, then load data atomically before /health becomes ready.

Render requires a listening port before its initial port-scan deadline. Keep
Gunicorn alive during the first COPY import, monitor both processes, and stop the
server if import fails. dataset_info is committed with all data in one transaction.
"""
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
from dotenv import load_dotenv


def main():
    root=Path(__file__).resolve().parent
    os.chdir(root)
    load_dotenv(root/'.env')
    port=os.environ.get('PORT','5050')
    if not port.isdigit() or not 1<=int(port)<=65535:
        raise SystemExit('PORT must be between 1 and 65535')
    stopping=threading.Event()
    children=[]
    def on_stop(signum,frame):
        stopping.set()
    signal.signal(signal.SIGTERM,on_stop)
    signal.signal(signal.SIGINT,on_stop)
    try:
        web=subprocess.Popen([sys.executable,'-m','gunicorn','--workers','1','--threads','4',
                              '--timeout','60','--bind',f'0.0.0.0:{port}','app:app'])
        children.append(web)
        loader=subprocess.Popen([sys.executable,str(root/'import_data.py'),'--prepared',str(root/'data')])
        children.append(loader)
        loaded=False
        while not stopping.is_set():
            if web.poll() is not None:
                return web.returncode or 1
            if not loaded and loader.poll() is not None:
                if loader.returncode:
                    print('Dataset import failed; stopping HTTP service.',file=sys.stderr,flush=True)
                    return loader.returncode
                loaded=True
                print('Dataset verified; HTTP health check can now succeed.',flush=True)
            stopping.wait(0.5)
        return 0
    finally:
        for child in children:
            if child.poll() is None:child.terminate()
        for child in children:
            try:child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill();child.wait()

if __name__=='__main__':
    raise SystemExit(main())
