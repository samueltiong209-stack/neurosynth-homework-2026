"""Import/verify prepared data, then run Gunicorn with environment configuration."""
import os
from pathlib import Path
import sys
from import_data import import_data

def main():
    root=Path(__file__).resolve().parent
    os.chdir(root)
    # db.py already loads backend/.env without overriding platform variables.
    port=os.environ.get('PORT','5050')
    if not port.isdigit() or not 1<=int(port)<=65535:raise SystemExit('PORT must be between 1 and 65535')
    import_data(root/'data')
    os.execv(sys.executable,[sys.executable,'-m','gunicorn','--workers','1','--threads','4',
                            '--timeout','60','--bind',f'0.0.0.0:{port}','app:app'])
if __name__=='__main__':main()
