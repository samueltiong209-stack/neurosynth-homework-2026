"""Extract the original dataset to portable CSV.gz, never predictions."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from source_data import read_source

PREFIX = 'terms_abstract_tfidf__'

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def prepare(source, output):
    frames = read_source(source)
    ann, coords, meta = (frames[n] for n in ('annotations','coordinates','metadata'))
    for df in frames.values():
        if df[['id','study_id','contrast_id']].isna().any().any(): raise ValueError('Missing IDs')
    if not ann.id.is_unique or not meta.id.is_unique: raise ValueError('Duplicate experiment IDs')
    ids = ann[['id','study_id','contrast_id']].astype(str)
    for df in (coords, meta):
        check = df[['id','study_id','contrast_id']].astype(str).drop_duplicates()
        merged = check.merge(ids, on='id', suffixes=('_a','_b'), how='left', validate='one_to_one')
        if merged.isna().any().any() or not all((merged[c+'_a'] == merged[c+'_b']).all() for c in ('study_id','contrast_id')):
            raise ValueError('ID relationships disagree')
    if set(meta.id) != set(ann.id): raise ValueError('Metadata/annotation IDs differ')
    if set(coords.space) != {'mni152_2mm'}: raise ValueError('Mixed or unsupported coordinate space')
    xyz = coords[['x','y','z']].to_numpy(dtype=float)
    if not np.isfinite(xyz).all(): raise ValueError('Invalid coordinates')
    columns = [c for c in ann if c.startswith(PREFIX)]
    terms = [c[len(PREFIX):].strip().lower() for c in columns]
    if len(set(terms)) != len(terms) or any(not t for t in terms): raise ValueError('Duplicate/empty terms')
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    counts = {}
    def write(name, header, rows):
        count = 0
        with gzip.open(out/(name+'.csv.gz'), 'wt', newline='', encoding='utf-8') as f:
            w = csv.writer(f); w.writerow(header)
            for row in rows: w.writerow(row); count += 1
        counts[name] = count
    # Metadata must agree within a publication; never silently pick conflicting rows.
    for sid, group in meta.groupby('study_id'):
        if any(group[c].nunique(dropna=False)>1 for c in ('title','authors','journal','year')):
            raise ValueError(f'Conflicting publication metadata: {sid}')
    m = meta.drop_duplicates('study_id').sort_values('study_id')
    write('studies', ['study_id','title','authors','journal','year'],
          m[['study_id','title','authors','journal','year']].itertuples(index=False,name=None))
    write('experiments', ['id','study_id','contrast_id'], ids.itertuples(index=False,name=None))
    write('terms', ['term_id','name'], enumerate(terms,1))
    write('coordinates', ['experiment_id','x','y','z'], coords[['id','x','y','z']].itertuples(index=False,name=None))
    def scores():
        for tid,col in enumerate(columns,1):
            values=ann[col].to_numpy(dtype=float)
            if not np.isfinite(values).all() or (values<0).any(): raise ValueError('Invalid term score')
            for i in np.flatnonzero(values>0): yield (str(ann.id.iloc[i]), tid, float(values[i]))
    write('term_scores', ['experiment_id','term_id','score'], scores())
    manifest = {'format_version':1,'source_sha256':sha256(source),'source_format':'gzip / NiMARE Dataset pickle',
                'space':'mni152_2mm','annotation_prefix':PREFIX,'counts':counts,
                'id_definition':'id = experiment/contrast; study_id = publication. Results deduplicate study_id.',
                'files':{name+'.csv.gz':sha256(out/(name+'.csv.gz')) for name in counts}}
    (out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
    return manifest

if __name__ == '__main__':
    p=argparse.ArgumentParser(); p.add_argument('--source',default='../neurosynth_dataset.gz');p.add_argument('--output',default='data')
    a=p.parse_args(); prepare(a.source,a.output)
