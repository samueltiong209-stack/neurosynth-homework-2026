import os
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
from dotenv import load_dotenv
load_dotenv(Path(__file__).with_name('.env'))

def connect():
    url=os.environ.get('DATABASE_URL')
    if not url: raise RuntimeError('DATABASE_URL is required; see .env.example')
    return psycopg.connect(url, row_factory=dict_row, connect_timeout=10,
                           options='-c statement_timeout=30000')
