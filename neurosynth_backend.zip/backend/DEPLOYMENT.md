# 免費部署狀態與限制

查閱日期：2026/10/30（Asia/Taipei）。目前**尚無可繳交的公開網址**，沒有建立付費方案，沒有公開上傳資料。本機網站／資料庫與 ZIP 可先使用。

## 建議方案：Render Free Web + Render Free PostgreSQL

官方依據：

- 免費方案：https://render.com/docs/free
- Flask：https://render.com/docs/deploy-flask
- Blueprint：https://render.com/docs/blueprint-spec
- Python 版本：https://render.com/docs/python-version

|項目|目前官方限制與本作業影響|
|---|---|
|網站|Free，閒置 15 分鐘休眠，下次請求約一分鐘喚醒；每個 workspace 每月合計 750 免費 instance 小時。|
|網頁檔案|暫時性檔案系統；重啟／休眠後寫入檔案可能消失。因此使用獨立 PostgreSQL，不把 SQLite 存在網站磁碟。|
|PostgreSQL 容量|1 GB，workspace 同時只能有一個免費 PostgreSQL；本機實測含索引約 238 MB，可容納本資料。|
|期限|建立後 30 天到期，屆時立即無法查詢；之後有 14 天付費升級寬限，寬限後刪除。寬限期不是免費可用期。|
|到期示例|若 2026/10/30 建立，約 2026/11/29 同時刻到期，約 12/13 後刪除；以平台顯示的精確時間為準。11/5 繳交可以涵蓋，但老師晚於期限評分會無法用。|
|備份|免費資料庫無平台備份；本地 ZIP/data 是可重建來源，不能視為雲端自動備份。|
|維護|資料庫可能維護／重啟；免費網站可能重啟。|
|額度與費用|流量、build 分鐘有額度。未綁付款方式時超額會停服務／停止建置；有付款方式可能產生超額費用。以不額外付費為原則，若平台要求信用卡先停下，不代填、不升級。|
|資源|Free Web 512 MB；runtime 不載入 NiMARE／pandas，只串流 CSV 匯入。Free 不提供 Shell／one-off jobs，所以 `start.sh` 先匯入再啟動 Gunicorn。|

兩個資源的 `plan: free` 都已明寫在 render.yaml，避免省略時預設付費方案。網站與資料庫同在 singapore，透過 Render internal connectionString 連線，DB 外部 IP allowlist 設為空。尚未在 Render 上驗證此 Blueprint；建立前應在介面確認兩個資源都顯示 Free／$0，以及資料庫到期日。

若老師要求 30 天以後仍可用，應再確認其他免費 PostgreSQL 的當時容量／保存政策並先溝通，或重建免費資料庫再匯入（不得假設平台允許無限重新申請）。不會為了免費而悄悄換成 SQLite、MySQL 或假資料。

## PythonAnywhere 不適合本次免費 PostgreSQL 要求

官方 https://help.pythonanywhere.com/pages/Postgres 明確表示 PostgreSQL 需要付費帳號；連外部 PostgreSQL 也要求付費帳號。

https://help.pythonanywhere.com/pages/FreeAccountsFeatures 列出免費帳號 100 CPU 秒、512 MiB 磁碟、1 個 web app／1 worker／1 個月 expiry。舊帳號的 MySQL 條件與新帳號不同，但 MySQL 並不符合這次指定 PostgreSQL，故沒有改用。

## 公開前需要使用者配合

登入 Render／GitHub、授權第三方讀取 repo，以及將本機資料公開上傳，均需先告知使用者；本次已告知並取得同意，但尚未實際上傳。預計公開的具體內容是：**backend 程式與約 18 MB 的可攜資料（原始論文書目、研究／實驗 ID、MNI 座標、TF-IDF 詞彙分數）**。不包含原始 notebook、decoding_results、模型、`.env` 或帳密。API 會公開研究書目與符合條件的論文 ID。

使用者已於 2026/10/30 同意上述資料上傳 GitHub／Render 並使用兩項 Free／$0 方案部署；不需要重複詢問相同範圍。Render 帳號連線尚未完成。不要在對話中貼密碼、token 或 DATABASE_URL；直接在平台登入或設定。repo 也可為私有，但 Render 仍需授權讀取，網站 API 仍公開。

## 操作流程備查（實際協作時每次只做一步）

1. 優先由使用者安裝並連接 Render 官方外掛；已提供連線建議但尚未確認成功。如無法連線，改由使用者在 https://dashboard.render.com 登入，成功畫面為 Render Dashboard。此環境的瀏覽器自動操作尚未取得系統權限，不能宣稱已代登入。
2. 確認公開資料範圍，準備 Git repository，**以 backend/ 內容為 repository 根目錄**（render.yaml 也在根目錄）。如要從整個舊工作區推 Git，必須先設 rootDir／Blueprint 路徑與排除舊資料，建議獨立 repo。
3. `data/` 預設被 .gitignore 忽略以避免意外上傳。取得使用者對具體資料的同意後，才能明確加入這六個檔案：manifest.json 和五個 CSV.gz。最終 repo 必須包含 data，否則 start.sh 會報錯。
4. Render New → Blueprint → 選擇 repo。確認 Web、PostgreSQL 都為 **Free／$0**，region 相同。若無免費方案、出現卡號或付款要求，先停止並回報。
5. 建立後等待網站顯示 Live，`/health` 回傳 status=ok 與真實列數。記下 HTTPS 公開網址及資料庫精確到期日。
6. 本機執行 README 的 `verify.py --base-url ...`，完整驗證公開四個 API 與 edge cases。公開測試成功後更新 README、本文件與 ZIP，才可交付。

以上為準備好的操作說明，**不代表部署已成功**。
