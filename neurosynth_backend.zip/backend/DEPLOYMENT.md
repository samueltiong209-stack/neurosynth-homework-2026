# 免費部署狀態與限制

查閱日期：2026/10/30（Asia/Taipei）。目前已建立 Free PostgreSQL 與 Free Web Service，網站首次匯入進行中，**尚未完成公開驗證，暫不能視為可繳交完成品**。沒有建立付費方案。

## 本次實際使用：Render Free Web + Render Free PostgreSQL

官方依據：

- 免費方案：https://render.com/docs/free
- Flask：https://render.com/docs/deploy-flask
- Blueprint：https://render.com/docs/blueprint-spec
- Python 版本：https://render.com/docs/python-version

|項目|目前官方限制與本作業影響|
|---|---|
|網站|Free，閒置 15 分鐘休眠，下次請求約一分鐘喚醒；每個 workspace 每月合計 750 免費 instance 小時。|
|網頁檔案|暫時性檔案系統；重啟／休眠後寫入檔案可能消失。因此使用獨立 PostgreSQL，不把 SQLite 存在網站磁碟。|
|PostgreSQL 容量|1 GB，workspace 同時只能有一個免費 PostgreSQL；本機實測含索引約 238 MB，可容納本資料。|
|期限|建立後 30 天到期，屆時立即無法查詢；之後有 14 天付費升級寬限，寬限後刪除。寬限期不是免費可用期。|
|到期示例|若 2026/10/30 建立，約 2026/11/29 同時刻到期，約 12/13 後刪除；以平台顯示的精確時間為準。11/5 繳交可以涵蓋，但老師晚於期限評分會無法用。|
|備份|免費資料庫無平台備份；本地 ZIP/data 是可重建來源，不能視為雲端自動備份。|
|維護|資料庫可能維護／重啟；免費網站可能重啟。|
|額度與費用|流量、build 分鐘有額度。未綁付款方式時超額會停服務／停止建置；有付款方式可能產生超額費用。以不額外付費為原則，若平台要求信用卡先停下，不代填、不升級。|
|資源|Free Web 512 MB；runtime 不載入 NiMARE／pandas，只串流 CSV 匯入。Free 不提供 Shell／one-off jobs，因此 `serve.py` 先啟動 Gunicorn 監聽連接埠，同時在背景匯入；資料完成提交後 health 才會回傳成功。|

兩個資源的 `plan: free` 都已明寫在 render.yaml，避免省略時預設付費方案。網站與資料庫同在 singapore，透過 Render internal connectionString 連線，DB 外部 IP allowlist 設為空。此 Blueprint 是替代來源版型；本次實際用網頁設定建置，已確認兩個資源為 Free／$0 與到期日。

若老師要求 30 天以後仍可用，應再確認其他免費 PostgreSQL 的當時容量／保存政策並先溝通，或重建免費資料庫再匯入（不得假設平台允許無限重新申請）。不會為了免費而悄悄換成 SQLite、MySQL 或假資料。

## PythonAnywhere 不適合本次免費 PostgreSQL 要求

官方 https://help.pythonanywhere.com/pages/Postgres 明確表示 PostgreSQL 需要付費帳號；連外部 PostgreSQL 也要求付費帳號。

https://help.pythonanywhere.com/pages/FreeAccountsFeatures 列出免費帳號 100 CPU 秒、512 MiB 磁碟、1 個 web app／1 worker／1 個月 expiry。舊帳號的 MySQL 條件與新帳號不同，但 MySQL 並不符合這次指定 PostgreSQL，故沒有改用。

## 已取得授權與實際來源配置

登入 Render／GitHub、授權第三方讀取 repo，以及將本機資料公開上傳，均需先告知使用者；本次已告知、取得同意並實際上傳。公開的具體內容是：**backend 程式與約 18 MB 的可攜資料（原始論文書目、研究／實驗 ID、MNI 座標、TF-IDF 詞彙分數）**。不包含原始 notebook、decoding_results、模型、`.env` 或帳密。API 會公開研究書目與符合條件的論文 ID。

使用者已於 2026/10/30 同意上述資料上傳 GitHub／Render 並使用兩項 Free／$0 方案部署；不需要重複詢問相同範圍。使用者已登入 Render 與 GitHub，已經由 Safari 完成網站及資料庫建立，不需再安裝外掛。不要在對話中貼密碼、token 或 DATABASE_URL；直接在平台登入或設定。repo 也可為私有，但 Render 仍需授權讀取，網站 API 仍公開。

## 本次實際部署設定

- GitHub 公開來源：https://github.com/samueltiong209-stack/neurosynth-homework-2026
- 來源 commit：`3f319c1ba3a6057335be4d82a64277f77ef6ebb8`
- Web：`neurosynth-homework-2026`，Free / $0，Singapore，Python 3.14.0。
- PostgreSQL：`neurosynth-homework-db`，Free / $0，Singapore，PostgreSQL 17。
- DB 實際到期時間：2026/11/29 22:42:19，Asia/Taipei。到期後不可查詢；不要把之後的 14 天寬限當成可用期。
- 已移除 PostgreSQL 的 `0.0.0.0/0` 公網允許規則；只讓 Render 同區域網站使用內部 URL。
- `DATABASE_URL` 在 Render Environment 設定，使用平台產生的內部 URL；不放入 GitHub／ZIP，也沒有要求使用者在對話貼密碼。
- Health Check Path：`/health`。

因本環境未連接 GitHub CLI，實際採用 GitHub 網頁上傳**安全 ZIP**的方式：repository 根目錄有 `neurosynth_backend.zip` 與外部 README；Render build 先解壓，真正 .py、requirements 與 data 在解壓的 `backend/` 內。公開下載的 ZIP 已與本機 SHA-256 核對一致。不要把這種來源配置與 README 的「backend 內容直接作為 repo 根目錄」混用。

實際 Build Command：

```sh
python -m zipfile -e neurosynth_backend.zip . && python -m pip install -r backend/requirements.txt
```

實際 Start Command：

```sh
sh backend/start.sh
```

根目錄 Root Directory 留空。`PYTHON_VERSION=3.14.0`；`DEFAULT_RADIUS_MM` 與 `DEFAULT_THRESHOLD` 未另覆寫，使用程式的 6 mm 與 0 預設值。公開 Git repository URL 模式不需要授予 Render 讀取其他私有 GitHub repo 的權限；更新來源之後需手動部署。

`render.yaml` 是另一種**將 backend 內容直接放在 repo 根目錄**的 Blueprint 範本，不是本次安全 ZIP 來源的直接建置設定。若使用該範本，請先檢查是否會重複建立既有資源，不要無意建立另一個資料庫或付費資源。

## 首次部署修正

首次約 105 萬筆詞彙分數寫入超過 Render 初始連接埠偵測上限，原本先匯入才開站的方式因此失敗。已修改 `serve.py` 為先監聽 HTTP、背景原子匯入，並監控兩個子程序：匯入失敗就關閉 HTTP，資料未提交時 health 不成功。沒有換資料庫、縮減資料或升級付費。

## 尚待完成

首次雲端匯入及啟動完成後，執行完整 `verify.py --base-url ...`，核對公開四個 API 的每一頁與原始資料。成功後再更新本文件、README、測試報告及繳交 ZIP。
