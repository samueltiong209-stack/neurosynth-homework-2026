"""Cross-check complete API result sets against the original pickle, locally or over HTTPS."""
import argparse
import json
import math
from pathlib import Path
import ssl
import time
from urllib.parse import quote
from urllib.request import urlopen
from urllib.error import HTTPError
import numpy as np
from source_data import read_source


def verify(source,base_url=None,report=None):
    started=time.monotonic()
    frames=read_source(source); ann=frames['annotations']; coords=frames['coordinates']; meta=frames['metadata'].set_index('study_id')
    xyz=coords[['x','y','z']].to_numpy(dtype=float)
    if base_url:
        def get(path):
            try:
                with urlopen(base_url.rstrip('/')+path,timeout=180) as r:return r.status,json.loads(r.read())
            except HTTPError as e:return e.code,json.loads(e.read())
    else:
        from app import create_app
        client=create_app({'TESTING':True}).test_client()
        def get(path):
            response=client.get(path);return response.status_code,response.get_json()
    def term(name,threshold=0):return set(ann.loc[ann['terms_abstract_tfidf__'+name]>threshold,'study_id'].astype(str))
    def location(point,radius=6):
        distances=np.sqrt(((xyz-np.array(point))**2).sum(axis=1))
        return set(coords.loc[distances<=radius,'study_id'].astype(str))
    checks=[]
    def check(path,expected,status=200):
        url=path+('&' if '?' in path else '?')+'per_page=100'
        code,body=get(url)
        assert code==status,(path,code,body)
        if status!=200:
            assert 'error' in body and body['error']['message'];checks.append({'path':path,'status':code});return
        assert body['pagination']['total']==len(expected),(path,body['pagination'],len(expected))
        rows=list(body['studies']); pages=body['pagination']['total_pages']
        for page in range(2,pages+1):
            c,b=get(url+'&page='+str(page));assert c==200 and b['pagination']['total']==len(expected)
            rows.extend(b['studies'])
        ids=[r['study_id'] for r in rows]
        assert ids==sorted(expected),(path,'Incorrect, duplicate, missing, or unstable study IDs')
        for r in rows:
            raw=meta.loc[r['study_id']]
            # This source has one contrast per publication.
            for key in ('title','authors','journal','year'):assert r[key]==raw[key],(path,r['study_id'],key)
        checks.append({'path':path,'status':code,'total':len(ids),'pages_verified':max(1,pages),'all_study_ids_and_metadata_match':True})
        print(f'PASS {path}: {len(ids)} studies',flush=True)
    a=term('memory');b=term('fear');l=location((-22,0,-20));r=location((22,0,-20))
    cases=[('/terms/memory/studies',a),('/terms/fear/studies',b),
           ('/locations/-22_0_-20/studies',l),('/locations/22_0_-20/studies',r),
           ('/dissociate/terms/memory/fear',a-b),('/dissociate/terms/fear/memory',b-a),
           ('/dissociate/locations/-22_0_-20/22_0_-20',l-r),
           ('/dissociate/locations/22_0_-20/-22_0_-20',r-l),
           ('/dissociate/terms/memory/memory',set()),
           ('/dissociate/locations/-22_0_-20/-22_0_-20',set()),
           ('/terms/memory/studies?threshold=0.1',term('memory',0.1)),
           ('/dissociate/terms/memory/fear?threshold=0.1',term('memory',0.1)-term('fear',0.1)),
           ('/locations/-22_0_-20/studies?radius=10',location((-22,0,-20),10)),
           ('/dissociate/locations/-22_0_-20/22_0_-20?radius=10',location((-22,0,-20),10)-location((22,0,-20),10)),
           ('/terms/%20MeMoRy%20/studies',a),('/terms/memory/studies?threshold=1000000',set()),
           ('/locations/200_200_200/studies',set())]
    # A real focus exactly 6 mm from the query; confirms inclusive sphere boundary.
    x,y,z=xyz[0];point=(x+6,y,z)
    cases.append((f'/locations/{point[0]}_{point[1]}_{point[2]}/studies',location(point)))
    for path,expected in cases:check(path,expected)
    invalid=[('/terms/this_term_does_not_exist_999/studies',404),('/dissociate/terms/memory/this_term_does_not_exist_999',404),
             ('/locations/1_2/studies',400),('/locations/nan_0_0/studies',400),('/locations/201_0_0/studies',400),
             ('/dissociate/locations/-22_0_-20/bad',400),('/dissociate/locations/bad/-22_0_-20',400),
             ('/locations/0_0_0/studies?radius=0',400),('/locations/0_0_0/studies?radius=-1',400),
             ('/locations/0_0_0/studies?radius=nan',400),('/locations/0_0_0/studies?radius=101',400),
             ('/terms/memory/studies?threshold=inf',400),('/terms/memory/studies?threshold=-1',400),
             ('/terms/memory/studies?page=0',400),('/terms/memory/studies?page=1.5',400),
             ('/terms/memory/studies?radius=6',400),('/terms/memory/studies?page=1&page=2',400)]
    for path,status in invalid:check(path,set(),status)
    code,body=get('/terms/memory/studies?per_page=101');assert code==400;checks.append({'path':'per_page=101','status':400})
    code,body=get('/terms/memory/studies?page=1000000');assert code==200 and body['studies']==[] and body['pagination']['total']==len(a)
    checks.append({'path':'page beyond end','status':200,'total_preserved':True})
    code,body=get('/health');assert code==200 and body['counts']['coordinates']==len(coords)
    checks.append({'path':'/health','status':200})
    # Phrase comes from the actual vocabulary, never fuzzy matching.
    phrase=next(c[len('terms_abstract_tfidf__'):] for c in ann if c.startswith('terms_abstract_tfidf__') and ' ' in c)
    check('/terms/'+quote(phrase,safe='')+'/studies',term(phrase))
    result={'status':'passed','mode':('public HTTPS' if base_url.startswith('https://') else 'network HTTP (local)') if base_url else 'Flask client + real PostgreSQL',
            'base_url':base_url,'checks':checks,'checks_passed':len(checks),'elapsed_seconds':round(time.monotonic()-started,2),
            'comparison':'every page, exact sorted publication IDs, no duplicates, original publication metadata',
            'definition_status':'Dissociate = A minus B, provisional; instructor repository HTTP 404'}
    if report:Path(report).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='checks'},ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',default='../neurosynth_dataset.gz');p.add_argument('--base-url');p.add_argument('--report',default='reports/verification.json')
    a=p.parse_args();verify(a.source,a.base_url,a.report)
