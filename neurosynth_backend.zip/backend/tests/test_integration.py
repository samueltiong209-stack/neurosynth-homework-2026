from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from verify import verify

def test_real_dataset_against_sql():
    root=Path(__file__).resolve().parents[1]
    result=verify(root.parent/'neurosynth_dataset.gz',report=root/'reports/verification.json')
    assert result['checks_passed']>=38
