CREATE TABLE IF NOT EXISTS studies (
    study_id text PRIMARY KEY, title text NOT NULL, authors text NOT NULL,
    journal text NOT NULL, year integer NOT NULL
);
CREATE TABLE IF NOT EXISTS experiments (
    id text PRIMARY KEY, study_id text NOT NULL REFERENCES studies(study_id), contrast_id text NOT NULL,
    UNIQUE (study_id, contrast_id)
);
CREATE TABLE IF NOT EXISTS terms (term_id integer PRIMARY KEY, name text UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS coordinates (
    experiment_id text NOT NULL REFERENCES experiments(id), x double precision NOT NULL,
    y double precision NOT NULL, z double precision NOT NULL
);
CREATE TABLE IF NOT EXISTS term_scores (
    experiment_id text NOT NULL REFERENCES experiments(id), term_id integer NOT NULL REFERENCES terms(term_id),
    score double precision NOT NULL CHECK (score > 0), PRIMARY KEY (term_id,experiment_id)
);
CREATE TABLE IF NOT EXISTS dataset_info (singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton), manifest jsonb NOT NULL);
CREATE INDEX IF NOT EXISTS experiments_study_idx ON experiments(study_id);
CREATE INDEX IF NOT EXISTS coordinates_xyz_idx ON coordinates(x,y,z);
CREATE INDEX IF NOT EXISTS coordinates_experiment_idx ON coordinates(experiment_id);
CREATE INDEX IF NOT EXISTS term_scores_lookup_idx ON term_scores(term_id,score,experiment_id);
