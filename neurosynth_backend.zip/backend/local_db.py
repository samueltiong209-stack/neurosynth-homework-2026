"""Start a password-protected loopback-only PostgreSQL for local development."""
import argparse
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import tempfile
import psycopg
from psycopg import sql
from dotenv import dotenv_values

ROOT=Path(__file__).resolve().parent
STATE=Path.home()/'Library'/'Application Support'/'neurosynth-homework'
PGDATA=STATE/'pgdata'
PORT=55432

def binary(name):
    value=shutil.which(name)
    if value:return value
    candidate=Path('/opt/homebrew/opt/postgresql@17/bin')/name
    if candidate.exists():return str(candidate)
    raise SystemExit('Install PostgreSQL 17 first: brew install postgresql@17')

def run(name,*args,check=True):
    return subprocess.run([binary(name),*map(str,args)],check=check)

def main(action):
    if action=='stop':
        run('pg_ctl','-D',PGDATA,'stop');return
    STATE.mkdir(parents=True,exist_ok=True)
    env_path=ROOT/'.env'
    if not PGDATA.exists():
        if env_path.exists():raise SystemExit('.env already exists; preserve it and configure PostgreSQL manually.')
        password=secrets.token_urlsafe(32)
        with tempfile.NamedTemporaryFile(mode='w') as f:
            f.write(password+'\n');f.flush()
            run('initdb','-D',PGDATA,'-U','neurosynth_local','--encoding=UTF8','--locale=C','--auth=scram-sha-256','--pwfile',f.name)
        with (PGDATA/'postgresql.conf').open('a') as f:
            f.write(f"\nlisten_addresses = '127.0.0.1'\nport = {PORT}\nunix_socket_directories = '/tmp'\n")
        env_path.write_text(f'DATABASE_URL=postgresql://neurosynth_local:{password}@127.0.0.1:{PORT}/neurosynth\nDEFAULT_RADIUS_MM=6\nDEFAULT_THRESHOLD=0\n')
        try:env_path.chmod(0o600)
        except OSError:pass
    url=dotenv_values(env_path).get('DATABASE_URL')
    if not url:raise SystemExit('Missing local .env; do not overwrite existing PGDATA.')
    status=subprocess.run([binary('pg_ctl'),'-D',str(PGDATA),'status'],capture_output=True)
    if status.returncode!=0:run('pg_ctl','-D',PGDATA,'-l',STATE/'postgres.log','start')
    # Use conninfo parsing rather than altering the password-bearing URL text.
    info=psycopg.conninfo.conninfo_to_dict(url);info['dbname']='postgres'
    with psycopg.connect(**info,autocommit=True) as conn:
        if not conn.execute("SELECT 1 FROM pg_database WHERE datname='neurosynth'").fetchone():
            conn.execute(sql.SQL('CREATE DATABASE {}').format(sql.Identifier('neurosynth')))
    print('Local PostgreSQL ready at 127.0.0.1:55432; credentials saved only in backend/.env.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['start','stop'],default='start',nargs='?')
    main(p.parse_args().action)
