"""Read this historical NiMARE pickle without importing NiMARE or its models.
Only explicitly listed globals are allowed. Still accept only the supplied trusted file.
"""
import gzip
import pickle
from pathlib import Path

class _Container:
    def __setstate__(self, state):
        self.__dict__.update(state)

class _Discarded:
    def __setstate__(self, state):
        pass

class DatasetReader(pickle.Unpickler):
    ALLOWED = {
        ('numpy.core.multiarray', '_reconstruct'), ('numpy._core.multiarray', '_reconstruct'),
        ('numpy', 'ndarray'), ('numpy', 'dtype'), ('builtins', 'slice'),
        ('pandas.core.frame', 'DataFrame'), ('pandas.core.internals.managers', 'BlockManager'),
        ('pandas._libs.internals', '_unpickle_block'),
        ('pandas.core.indexes.base', '_new_Index'), ('pandas.core.indexes.base', 'Index'),
        ('pandas.core.indexes.range', 'RangeIndex'),
    }
    DISCARDED = {
        ('nilearn.maskers.nifti_masker', 'NiftiMasker'), ('nibabel.nifti1', 'Nifti1Image'),
        ('nibabel.nifti1', 'Nifti1Header'), ('nibabel.nifti1', 'Nifti1Extensions'),
        ('nibabel.fileholders', 'FileHolder'), ('joblib.memory', 'Memory'),
    }
    def find_class(self, module, name):
        if (module, name) == ('nimare.dataset', 'Dataset'):
            return _Container
        if (module, name) in self.DISCARDED:
            return _Discarded
        if (module, name) not in self.ALLOWED:
            raise pickle.UnpicklingError(f'Unsupported pickle global: {module}.{name}')
        return super().find_class(module, name)

def read_source(path):
    path = Path(path)
    with path.open('rb') as f:
        if f.read(2) != b'\x1f\x8b':
            raise ValueError('Expected gzip magic bytes, not merely a .gz filename')
    with gzip.open(path, 'rb') as f:
        d = DatasetReader(f).load()
    return {name: getattr(d, '_Dataset__' + name) for name in ('annotations', 'coordinates', 'metadata')}
